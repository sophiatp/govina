<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; March-2019 <a href="#">Govina team</a>.</strong> All rights
    reserved.
</footer>
