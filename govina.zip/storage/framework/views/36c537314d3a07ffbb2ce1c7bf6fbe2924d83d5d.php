<?php $__env->startSection('title'); ?>
    GOVINA-Trang chủ
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content_top">
    <div class="heading">
        <h3>Danh Sách Sản Phẩm</h3>
    </div>
    <div class="clear"></div>
</div>

<div class="section group">
    <?php $__currentLoopData = $congAnNinh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="grid_1_of_4 images_1_of_4">
        <a href="<?php echo e(route('products.show', $item['slug'])); ?>">
            <img src="<?php echo e(asset('images/' . $item['image'])); ?>" alt="" height="160px"/>
        </a>
        <h3><?php echo e($item['name']); ?></h3>
        <div class="price-details">
            <div class="price-number">
                <p>
                    <span class="rupees">Giá : <?php echo e($item['price']); ?> VND</span>
                </p>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="section group">
    <?php $__currentLoopData = $temTu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="grid_1_of_4 images_1_of_4">
        <a href="preview.html"><img src="<?php echo e(asset('images/' . $item['image'])); ?>" alt="Image" height="160px"/></a>
        <h3><?php echo e($item['name']); ?></h3>
        <div class="price-details">
            <div class="price-number">
                <p><span class="rupees">Giá: <?php echo e($item['price']); ?> VND</span></p>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="section group">
    <?php $__currentLoopData = $keKhoHang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="grid_1_of_4 images_1_of_4">
        <a href="preview.html"><img src="<?php echo e(asset('images/' . $item['image'])); ?>" alt="Image" height="160px"/></a>
        <h3><?php echo e($item['name']); ?></h3>
        <div class="price-details">
            <div class="price-number">
                <p><span class="rupees">Giá: <?php echo e($item['price']); ?> VND</span></p>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="section group">
    <?php $__currentLoopData = $goTemTu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="grid_1_of_4 images_1_of_4">
        <a href="preview.html"><img src="<?php echo e(asset('images/' . $item['image'])); ?>" alt="Image" height="160px"/></a>
        <h3><?php echo e($item['name']); ?></h3>
        <div class="price-details">
            <div class="price-number">
                <p><span class="rupees">Giá: <?php echo e($item['price']); ?> VND</span></p>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="section group">
    <?php $__currentLoopData = $thietBiSieuthi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="grid_1_of_4 images_1_of_4">
        <a href="preview.html"><img src="<?php echo e(asset('images/' . $item['image'])); ?>" alt="Image" height="160px"/></a>
        <h3><?php echo e($item['name']); ?></h3>
        <div class="price-details">
            <div class="price-number">
                <p><span class="rupees">Giá: <?php echo e($item['price']); ?> VND</span></p>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.home.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>