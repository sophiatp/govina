<?php $__env->startSection('title'); ?>
    GOVINA-<?php echo e($subCategory['name']); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content_top">
        <div class="heading">
            <h3>Danh Sách Sản Phẩm <?php echo e($subCategory['name']); ?></h3>
        </div>
        <div class="clear"></div>
    </div>
    <?php if(count($products) > 1): ?>
    <div class="section group">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="grid_1_of_4 images_1_of_4">
                <a href="<?php echo e(route('products.show', $item['slug'])); ?>">
                    <img src="<?php echo e(asset('images/' . $item['image'])); ?>" alt="" height="160px"/>
                </a>
                <h3><?php echo e($item['name']); ?></h3>
                <div class="price-details">
                    <div class="price-number">
                        <p>
                            <span class="rupees">Giá : <?php echo e($item['price']); ?> VND</span>
                        </p>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>
        <div class="section group" style="margin-top: 30px; text-align: center">
            <p>Không có sản phẩm nào!</p>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.home.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>