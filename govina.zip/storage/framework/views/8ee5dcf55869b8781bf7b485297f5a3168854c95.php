<?php $__env->startSection('contentHeader'); ?>
    <section class="content-header">
        <h1>
            Quản lý danh mục
            <small>Danh sách danh mục</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Quản lý danh mục</a></li>
            <li class="active">Danh sách danh mục</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <p>Danh sách danh mục</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>