<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="main-category"><a href="#" class="main-category-link"><?php echo e($category['name']); ?></a></li>
    <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($subCategory['category_id'] == $category['id']): ?>
            <li><a href="<?php echo e(route('index.productBySubCategory', $subCategory['slug'])); ?>"><?php echo e($subCategory['name']); ?></a></li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
